﻿/*
 * <кодировка символов>
 *   Cyrillic (UTF-8 with signature) - Codepage 65001
 * </кодировка символов>
 *
 * <сводка>
 *   EcoLab1
 * </сводка>
 *
 * <описание>
 *   Данный исходный файл является точкой входа
 * </описание>
 *
 * <автор>
 *   Copyright (c) 2018 Vladimir Bashev. All rights reserved.
 * </автор>
 *
 */

#include "IEcoSystem1.h"
#include "IdEcoMemoryManager1.h"
#include "IdEcoInterfaceBus1.h"
#include "IdEcoLab1.h"

/*
 * Вспомогательные функции для тестирования
 */

/* Функция для проверки отсортированности массива */
static int32_t IsSortedInt32(int32_t* array, uint32_t size) {
    uint32_t i;
    for (i = 0; i < size - 1; i++) {
        if (array[i] > array[i + 1]) {
            return 0;
        }
    }
    return 1;
}

/*
 *
 * <сводка>
 *   Функция EcoMain
 * </сводка>
 *
 * <описание>
 *   Функция EcoMain - точка входа
 * </описание>
 *
 */
int16_t EcoMain(IEcoUnknown* pIUnk) {
    int16_t result = -1;
    IEcoSystem1* pISys = 0;
    IEcoInterfaceBus1* pIBus = 0;
    IEcoMemoryAllocator1* pIMem = 0;
    IEcoLab1* pIEcoLab1 = 0;
    char_t* name = 0;
    char_t* copyName = 0;

    /* Проверка входного параметра */
    if (pIUnk == 0) {
        return -1;
    }

    /* Получение системного интерфейса */
    result = pIUnk->pVTbl->QueryInterface(pIUnk, &GID_IEcoSystem, (void **)&pISys);
    if (result != 0 || pISys == 0) {
        goto Release;
    }

    /* Получение интерфейсной шины */
    result = pISys->pVTbl->QueryInterface(pISys, &IID_IEcoInterfaceBus1, (void **)&pIBus);
    if (result != 0 || pIBus == 0) {
        goto Release;
    }

#ifdef ECO_LIB
    /* Регистрация компонента */
    result = pIBus->pVTbl->RegisterComponent(pIBus, &CID_EcoLab1, (IEcoUnknown*)GetIEcoComponentFactoryPtr_1F5DF16EE1BF43B999A434ED38FE8F3A);
    if (result != 0) {
        goto Release;
    }
#endif

    /* Получение интерфейса памяти */
    result = pIBus->pVTbl->QueryComponent(pIBus, &CID_EcoMemoryManager1, 0, &IID_IEcoMemoryAllocator1, (void**) &pIMem);
    if (result != 0 || pIMem == 0) {
        goto Release;
    }

    /* Выделение блока памяти для теста MyFunction */
    name = (char_t *)pIMem->pVTbl->Alloc(pIMem, 10);
    if (name == 0) {
        result = -1;
        goto Release;
    }

    /* Заполнение блока памяти */
    pIMem->pVTbl->Fill(pIMem, name, 'a', 9);
    name[9] = 0; /* Завершающий ноль */

    /* Получение нашего компонента */
    result = pIBus->pVTbl->QueryComponent(pIBus, &CID_EcoLab1, 0, &IID_IEcoLab1, (void**) &pIEcoLab1);
    if (result != 0 || pIEcoLab1 == 0) {
        goto Release;
    }

    /* ТЕСТ 1: Простая сортировка маленького массива */
    {
        uint32_t TEST_SIZE = 5;
        int32_t* testArray = (int32_t*)pIMem->pVTbl->Alloc(pIMem, TEST_SIZE * sizeof(int32_t));
        
        if (testArray != 0) {
            testArray[0] = 5;
            testArray[1] = 2;
            testArray[2] = 8;
            testArray[3] = 1;
            testArray[4] = 3;

            result = pIEcoLab1->pVTbl->BubbleSortInt32(pIEcoLab1, testArray, TEST_SIZE);
            
            if (result == 0 && IsSortedInt32(testArray, TEST_SIZE)) {
                result = 0; 
            } else {
                result = -1;
            }

            pIMem->pVTbl->Free(pIMem, testArray);
        }
    }

    if (result == 0) {
        result = pIEcoLab1->pVTbl->MyFunction(pIEcoLab1, name, &copyName);
    }

    if (result == 0) {
        result = 0; 
    }

Release:
    if (name != 0) {
        pIMem->pVTbl->Free(pIMem, name);
    }
    if (pIEcoLab1 != 0) {
        pIEcoLab1->pVTbl->Release(pIEcoLab1);
    }
    if (pIMem != 0) {
        pIMem->pVTbl->Release(pIMem);
    }
    if (pIBus != 0) {
        pIBus->pVTbl->Release(pIBus);
    }
    if (pISys != 0) {
        pISys->pVTbl->Release(pISys);
    }

    return result;
}